# Panduan Penaksir Kendaraan — KMK 375 Tahun 2024

Versi tabel manual: 7 Oktober 2026. Dataset: 29.626 baris, normalisasi 2026-09-28.3.

## 1. Yang berubah pada versi ringan

Dataset sudah dipisahkan dari halaman aplikasi. Tidak perlu API, API AI, database, atau langganan Netlify. Aplikasi tetap HTML, CSS, dan JavaScript; data disajikan sebagai file JSON statis.

| Bagian | Ukuran / perilaku |
|---|---|
| HTML untuk tempel kode | Sekitar 111 KB; sebelumnya 7,85 MB. |
| HTML dalam folder web | Sekitar 19 KB; CSS dan JavaScript terpisah. |
| Katalog awal | Sekitar 60 KB: daftar merek, model, varian, dan lokasi. |
| Data lelang | 309 berkas kelompok jenis–merek–model; kelompok data dimuat sesuai filter merek/model. Memilih semua merek/model memuat seluruh data jenis kendaraan tersebut setelah tombol Tampilkan data ditekan. |
| Contoh Toyota Avanza | Sekitar 158 KB, berisi 1.095 baris sumber sebelum penyaringan kelayakan. |
| Komponen PDF | Dimuat ketika tombol unduh PDF pertama kali digunakan. Cetak melalui browser tidak memerlukannya. |
| CSV sumber lengkap | Sekitar 15,66 MB; diunduh hanya jika tombol unduh CSV digunakan. |

Ukuran merupakan ukuran file sebelum kompresi jaringan. Semua 29.626 baris sumber dipertahankan. Pemecahan file tidak mengubah harga lelang, normalisasi, atau rumus penaksiran.

Pengujian mencakup filter, pagination, maksimum tujuh pilihan, penyimpanan pilihan lintas merek, persentase negatif/positif/nol, kalkulator NJT/NJP, perhitungan dan PDF, draf, kegagalan koneksi dan coba ulang, respons filter terlambat, serta iframe. Tabel tetap merender maksimal 20/50/100 baris per halaman; pengujian 12.228 baris mobil menunjukkan render lokal sekitar 32 milidetik setelah data tersedia. Waktu unduhan tetap bergantung koneksi. Google Sites pengguna belum dipublikasikan dari sesi ini.

Isi paket:

| Lokasi | Fungsi |
|---|---|
| `web/index.html` | Halaman utama siap hosting. |
| `web/config.js` | Alamat katalog opsional. Kosongkan untuk hosting seluruh folder web pada alamat yang sama. |
| `web/assets/` | CSS, JavaScript, font, dan komponen PDF beserta lisensi. |
| `web/data/manifest.json` | Katalog yang menunjuk ke data setiap model. |
| `web/data/models-…/` | Data hasil lelang per model. Pertahankan nama folder dan file. |
| `web/data/Data_Lelang_Kendaraan_Klasifikasi.csv` | CSV lengkap untuk tombol unduh sumber. |
| `Penaksir_KMK375_Otomatis.html` | HTML ringan dengan program di dalamnya; dataset dan komponen PDF tetap eksternal. |
| `Pasted_text_KMK375_diperbarui.txt` | Kode HTML yang sama dalam format teks agar mudah disalin. |
| `src/` dan `data/` | Sumber program dan master dataset untuk pengelola. Tidak perlu diunggah untuk menjalankan aplikasi. |

## 2. Pemasangan tanpa Netlify

### A. Disarankan: GitHub Pages lalu sematkan URL

GitHub Pages tersedia untuk repositori publik pada GitHub Free. Folder yang diterbitkan menjadi dapat diakses publik; gunakan hosting kantor dengan pengaturan akses yang sesuai jika akses dataset perlu dibatasi. Langkah konfigurasi mengikuti [dokumentasi GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

1. Ekstrak `Penaksir_KMK375_Paket_Lengkap.zip`.
2. Buat repositori GitHub bernama, misalnya, `kmk375`, pilih **Public**, dan aktifkan **Add a README file** agar cabang `main` tersedia.
3. Pasang [GitHub Desktop](https://desktop.github.com/), masuk ke akun yang sama, lalu pilih **File → Clone Repository**. Pilih repositori `kmk375` dan klik **Clone**. GitHub Desktop memudahkan unggah ratusan file data sekaligus.
4. Buka folder repositori lokal tersebut. Salin **seluruh isi folder web** dari ZIP ke dalamnya. Hasilnya `index.html`, `config.js`, `assets`, dan `data` langsung berada pada akar repositori, bukan di dalam folder web tambahan. Jangan unggah file ZIP saja.
5. Pada GitHub Desktop, isi ringkasan perubahan, misalnya “Pasang penaksir KMK375”, klik **Commit to main**, lalu **Push origin**.
6. Buka repositori di GitHub → **Settings → Pages**. Pada Source pilih **Deploy from a branch**, lalu `main` dan `/(root)`, kemudian **Save**. Tunggu hingga GitHub menampilkan alamat situs.
7. Buka alamat tersebut, misalnya `https://USERNAME.github.io/kmk375/`. Pastikan status dataset terhubung, merek/model tersedia, pencarian berhasil, dan PDF dapat diunduh setelah isian lengkap.
8. Di editor Google Sites, pilih **Sisipkan → Sematkan → URL**, masukkan URL aplikasi, lalu atur tinggi area sematan. Publikasikan Google Sites dan coba dari halaman yang telah dipublikasikan.
9. Tambahkan tautan **Buka aplikasi di tab baru** menuju alamat aplikasi yang sama untuk pengguna yang browsernya membatasi unduhan atau penyimpanan dalam sematan.

Untuk memperbarui, salin isi folder web versi baru ke repositori yang sama, lakukan commit, lalu push. Alamat aplikasi tetap sama. Tidak perlu mengatur `manifestUrl` bila memakai susunan folder standar ini.

**Hosting kantor:** unggah isi folder web ke satu folder pada web server HTTPS. Pertahankan struktur `assets` dan `data`. Pastikan server menyajikan JSON/JavaScript/font dan mengizinkan halaman aplikasi disematkan oleh Google Sites. Setelah itu sematkan URL aplikasinya dengan cara yang sama.

### B. Jika tetap ingin menempel kode HTML di Google Sites

Dataset dan aset PDF tetap harus memiliki alamat HTTPS yang dapat diakses browser. Menempel HTML ringan saja belum menyediakan dataset bagi pengunjung.

1. Hosting isi folder web seperti cara A atau gunakan hosting kantor. Pastikan URL `https://USERNAME.github.io/kmk375/data/manifest.json` dapat dibuka dan menampilkan JSON.
2. Buka `Penaksir_KMK375_Otomatis.html` atau berkas TXT menggunakan editor teks. Cari baris ini:

```js
globalThis.KMK_CONFIG={manifestUrl:""};
```

3. Ganti dengan alamat sebenarnya, misalnya:

```js
globalThis.KMK_CONFIG={manifestUrl:"https://USERNAME.github.io/kmk375/data/manifest.json"};
```

4. Salin seluruh kode yang sudah diubah ke Google Sites → **Sisipkan → Sematkan → Sematkan kode**. Publikasikan dan uji. Google Sites mendukung HTML, CSS, dan JavaScript dalam sematan; pembatasan browser tetap dapat berlaku.
5. Biarkan `assets` sejajar dengan `data` pada hosting agar komponen PDF ditemukan otomatis. Jika aset berada di tempat lain, pengelola dapat mengisi properti `assetsUrl` pada `KMK_CONFIG` dengan URL folder aset.

Untuk sematan kode lintas domain, hosting file JSON dan font harus mengizinkan CORS dari sematan. Apabila muncul pesan CORS, gunakan sematan URL aplikasi pada cara A atau minta pengelola hosting mengatur akses file tersebut. Jangan menonaktifkan keamanan browser.

Panel **Atur alamat dataset** dalam aplikasi membantu mencoba URL, tetapi pengaturannya hanya berlaku pada browser tersebut bila penyimpanan tersedia. **Agar semua pengunjung langsung terhubung, atur URL pada kode sebelum dipasang.** Tautan berbagi Google Drive bukan URL JSON langsung yang dibutuhkan aplikasi.

### C. Mencoba di komputer sendiri

Jika Python sudah terpasang, buka terminal pada folder hasil ekstraksi dan jalankan:

```sh
python -m http.server 8000 --directory web
```

Pada Windows yang memakai Python Launcher, gunakan `py` sebagai pengganti `python`. Buka `http://localhost:8000/` di browser. Seluruh data dan aset berasal dari komputer sendiri; jangan menutup terminal selama aplikasi digunakan.

Membuka `web/index.html` melalui klik ganda dapat membuat browser memblokir pengambilan JSON lokal. Alternatifnya, buka HTML ringan lalu isi URL katalog HTTPS, atau impor CSV dari tab **Data & panduan** untuk sesi lokal. Bila komponen PDF eksternal belum dapat dimuat, gunakan **Cetak / simpan PDF** melalui dialog browser. Mode normal untuk pengunjung adalah aplikasi yang sudah dihosting, sehingga tidak perlu impor CSV.

## 3. Alur pemakaian tabel manual

1. **Objek:** isi jenis, merek, model, varian, tahun, tanggal, lokasi, kapasitas/kelas, dan kondisi. Merek/model/varian tetap terpisah dan memakai nama Indonesia yang singkat.
2. **Buka tabel pembanding:** filter awal mengikuti merek/model objek. Tidak ada baris yang dicentang otomatis.
3. **Filter:** pilih merek, model, tahun pembuatan, tahun lelang, KPKNL, atau cari kode/tipe/varian. Setelah merek/model berubah, klik **Tampilkan data**. Filter lainnya langsung berlaku. Pilihan semua merek/model tersedia untuk menelusuri jenis kendaraan yang sama.
4. **Periksa kelayakan:** secara default hanya data layak ditampilkan. Matikan **Hanya data layak** untuk melihat baris bermasalah beserta alasannya; baris bermasalah tidak dapat dicentang. Harga per unit dan kesebandingan tetap diperiksa panitia.
5. **Centang sendiri:** maksimal 7 pembanding, dapat berasal dari beberapa merek/model. Pilihan tetap tersimpan saat filter atau halaman berubah. Tombol pilihan di atas tabel dapat menghapus baris yang sedang tidak terlihat. **Hanya pilihan saya** menampilkan seluruh pilihan tanpa filter lain.
6. **Lanjut ke penyesuaian & perhitungan:** kategori lokasi dan tingkat tipe diisi per pembanding. Satu tingkat tipe bernilai 8%. Isi dasar kesetaraan/perbedaannya.
7. **Beda merek:** centang pada pembanding yang berbeda merek dari objek. Isi persentase, keterangan rumus, serta dasar dan sumber. Merek sama tetap 0%; ketidakcocokan centang dengan identitas merek harus diperbaiki sebelum PDF.
8. **Kalkulator opsional NJT/NJP:** buka Bantu hitung, masukkan harga objek dan pembanding, lalu klik **Hitung dan isi persentase**. Contoh NJT Rp175 juta dan NJP Rp200 juta menghasilkan `(175 − 200) / 200 × 100% = −12,5%`. Persentase yang tertulis dalam input adalah angka yang dipakai; teks rumus hanya dokumentasi dan tidak dieksekusi sebagai kode.
9. **Persentase manual:** boleh memakai titik/koma desimal, misalnya `-12,5` atau `8`. Positif menaikkan harga pembanding, negatif menurunkannya. Nol harus diisi `0`; kosong bukan nol. Jika mengubah hasil kalkulator, perbarui keterangan rumus dan sumber agar konsisten.
10. **Sumber lain:** gunakan **+ Isi pembanding dari sumber lain**, lalu lengkapi identitas, harga lelang per unit, tahun, lokasi, dan sumbernya.
11. **Jumlah dan alasan:** aplikasi menerima 2–7 pembanding. Pemakaian dua data diberi catatan pada hasil/PDF karena acuan KMK C.3 menyebut minimum tiga. Isi alasan pemilihan; aplikasi tidak mengunci pilihan pada rekomendasi tahap cukup. Pemeriksaan C.3–C.4 menjadi tanggung jawab panitia.
12. **Identitas, tim, PDF:** lengkapi administrasi, anggota panitia, serta dasar kategori lokasi. PDF A4 portrait memuat tabel lelang, penyesuaian, nilai akhir, tanda tangan, persentase merek dan uraian rumus/sumbernya. CSV perhitungan juga memuat rumus dan dasar penyesuaian.

## 4. Acuan KMK dan perilaku aplikasi

Acuan utama adalah PDF KMK 375 Tahun 2024 yang diberikan pengguna, terutama Lampiran C.2–C.5, D, dan contoh kertas kerja halaman 27–32. Aplikasi tidak menggantikan pemeriksaan atau penetapan oleh panitia.

| Pokok | Penerapan |
|---|---|
| Jumlah pembanding, C.3 | Acuan KMK: minimal 3, maksimal 7. Aplikasi menyediakan perhitungan manual 2–7; dua data diberi catatan jumlah pada PDF. |
| Tahap cukup, C.4 | Acuan: tahap pertama yang cukup memakai seluruh data sampai 7; bila lebih, pertahankan tahap sebelumnya dan isi dari harga terendah tahap terakhir. Versi ini memakai pilihan manual; urutan tahap diperiksa panitia, bukan dikunci oleh aplikasi. |
| Tahun pembuatan, C.3.b | Maksimal 5 tahun lebih tua/muda; daftar kandidat memprioritaskan tahun terdekat. Ketentuan harga terendah C.4 diterapkan ketika tahap terakhir melampaui batas 7. |
| Tahun lelang, C.3.c | Tahun taksiran −3 sampai tahun taksiran; transaksi masa depan dikeluarkan. |
| Tipe dan merek | Jenis mengikuti objek; tabel boleh memuat merek/model lain sesuai filter. Pilihan dan kesebandingan diperiksa manual. |
| Waktu, C.5.a | (Tahun taksiran − tahun lelang) × 2%. |
| Tahun pembuatan, C.5.b | (Tahun objek − tahun pembanding) × 5%, 7%, atau 10%, sesuai kelas kapasitas objek. |
| Kelas roda 2/3, C.2.b | Low ≤100 cc; middle >100–150 cc; high >150 cc. |
| Kelas roda 4+, C.2.b | Low ≤1.200 cc; middle >1.200–2.500 cc; high >2.500 cc. |
| Tipe, C.5.c.1 | Selisih tingkat × 8%; penyesuaian bertanda sesuai arah inferior/superior pembanding. |
| Merek, C.5.c.2 | Fpm (%) = (NJT − NJP) / NJP × 100%. Input persentase digunakan setelah Beda merek dicentang; keterangan rumus dan dasar/sumber wajib. Kalkulator harga tersedia sebagai bantuan. |
| Lokasi, C.5.d | (Kategori pembanding − kategori objek) × 5%. |
| Kondisi lelang | Kerusakan ≤80%: 0,7; >80–90%: 0,6; >90%: 0,5. Tanpa dokumen kepemilikan: 0,5. |
| Kondisi tanpa lelang | Kerusakan ≤80%: 1,0; >80–90%: 0,9; >90%: 0,8. |
| Perhitungan | Persentase dijumlahkan dan diterapkan pada harga lelang. Hasil per pembanding dirata-ratakan lalu dikalikan faktor kondisi; tidak ada pembulatan antara. |
| Pembulatan | Ribuan terdekat pada hasil akhir, mengikuti pola contoh lampiran (misalnya Rp2.660.482,86 → Rp2.660.000). Ketentuan C tidak menyebut aturan selalu ke atas. |
| Batam/Sabang | Tidak dicampur dengan wilayah lain. Sabang tidak disamakan dengan Banda Aceh. Pencarian konservatif mengikuti label lokasi pada dataset, sehingga lokasi sebenarnya tetap perlu diperiksa. |
| Masa berlaku, D | 6 bulan sejak tanggal penentuan nilai taksiran. |

Catatan aritmetika: beberapa angka hasil pada contoh lampiran tidak sama dengan penerapan rumus terhadap harga yang tertulis. Aplikasi menghitung ulang berdasarkan rumus. Contoh: Rp56.583.000 × 1,09 = Rp61.675.470. Aplikasi tidak menyalin angka hasil contoh yang berbeda dengan perhitungannya.

## 5. Batas data bawaan

- Semua 29.626 baris dipertahankan; 21.665 baris lolos pemeriksaan dasar untuk pencarian model sebelum filter tahun, merek, dan wilayah. Nama baku dipakai untuk pencarian, nama mentah ditampilkan untuk pemeriksaan.
- Data ambigu, kode lelang berulang, potensi lot beberapa kendaraan, tahun tidak valid, dan konflik kategori lokasi tidak dipakai otomatis. Lolos pemeriksaan dasar belum berarti harga per unit telah diverifikasi.
- Kategori terbaru bawaan **Semester I 2026**. Untuk tanggal pada Semester II 2026 atau periode lain, aplikasi meminta pemeriksaan kategori yang berlaku; panitia dapat mengubah kategori objek/pembanding dan mencatat dasarnya. Aplikasi tidak mengklaim memiliki kategori terbaru secara otomatis.
- Tahun lelang tersedia, tetapi tanggal transaksi lengkap tidak tersedia. Dataset tidak diperbarui dari internet secara otomatis.
- Kapasitas/varian/tier yang belum diketahui tidak diisi dengan angka rekaan. Varian pendek Indonesia tidak selalu cukup untuk memastikan kesetaraan mesin, transmisi, dan generasi.
- Filter tabel tidak menjalankan sepuluh tahap secara otomatis. Panitia menilai tahapan dan mencatat alasan pemilihan sesuai C.4.

## 6. Draf dan pembaruan dataset

**Draf:** Simpan draf menyimpan isian pada browser/perangkat tersebut. Unduh draf JSON untuk cadangan atau pindah perangkat. Jika penyimpanan dalam iframe dibatasi, gunakan JSON. Draf bukan penyimpanan bersama. Draf format v2 sebelumnya dapat dibuka: pembanding yang dahulu dicentang dibawa menjadi pilihan manual. Konfirmasi pemeriksaan dan kategori diminta kembali. Draf baru hanya menyimpan pembanding terpilih, bukan seluruh tabel.

**Impor CSV:** mengganti dataset sesi yang sedang dibuka. Pengunjung lain tetap memakai dataset pada hosting. Ini jalur pengelola/pemakaian lokal; memproses CSV besar dapat lebih lambat daripada memuat JSON per model. Tombol unduh CSV sumber mempertahankan file sumber lengkap yang terhubung atau diimpor.

**Mengganti dataset bawaan:** Node.js hanya diperlukan pada komputer pengelola untuk membangun file statis. Pertahankan kolom CSV normalisasi. Dari akar hasil ekstraksi, jalankan:

```sh
node src/build.cjs data/Data_Lelang_Kendaraan_Klasifikasi.csv
```

Builder menghasilkan `output/web`, HTML ringan, dan TXT. Builder tidak mengubah CSV sumber. Katalog baru menunjuk folder model dengan penanda versi dataset sehingga cache versi berbeda tidak tertukar. Unggah seluruh `output/web`; untuk pembaruan bertahap, unggah folder model baru dahulu, lalu `manifest.json`. Pertahankan folder model versi sebelumnya selama masih mungkin ada pengguna yang membuka katalog lama.

Jangan hanya mengubah CSV di hosting: pencarian menggunakan JSON hasil build. CSV mentah tanpa kolom normalisasi perlu dinormalisasi dahulu. Data dari model yang baru diminta disimpan sementara di memori browser, maksimal lima model; model lain diambil kembali saat diperlukan. Aplikasi ini belum melakukan sinkronisasi lelang dari internet secara otomatis.

**Pembaruan kode sematan:** bila memakai cara B, tempel ulang HTML terbaru dan isi kembali URL katalog. Bila memakai cara A, cukup perbarui isi folder web pada hosting yang sama.

**Isian pengguna:** tidak ada API AI, kunci API, analitik aplikasi, atau pengiriman isian penilaian ke server oleh kode aplikasi. Hosting menerima permintaan file seperti website biasa. PDF dan draf dihasilkan di browser. Dataset yang disajikan ke browser dapat diakses oleh pengunjung yang memiliki akses ke situs.

## 7. Jika ada masalah

| Gejala | Tindakan |
|---|---|
| Dataset belum terhubung | Periksa URL `manifest.json`, koneksi, dan keberadaan folder data. Klik **Muat ulang** setelah diperbaiki; unduh draf dahulu karena mengganti dataset mengosongkan pilihan sesi. |
| Halaman terbuka tetapi JSON lokal gagal | Jalankan server lokal pada cara C atau gunakan hosting HTTPS. Klik ganda file bukan pengganti server. |
| Model gagal dimuat | Periksa seluruh folder model; klik Tampilkan data untuk mencoba ulang. Bila sebagian unduhan gagal, tabel tidak menampilkan hasil parsial. Pilihan sebelumnya tetap tersimpan. |
| CORS saat sematkan kode | Gunakan sematan URL aplikasi atau atur CORS pada hosting data/font. |
| Kandidat hanya terlihat 20 | Gunakan halaman berikutnya, ubah ukuran halaman, atau cari pada hasil. Semua kandidat tetap tersedia. |
| Pilihan kedelapan tidak bisa dicentang | Lepaskan satu pilihan terlebih dahulu; batasnya 7. |
| PDF belum aktif | Lengkapi kolom wajib dan pemeriksaan. Pastikan centang Beda merek sesuai identitas, persentase/rumus/sumber lengkap, dan alasan pemilihan terisi. |
| Unduh PDF gagal memuat komponen | Pastikan seluruh folder assets ikut diunggah; coba ulang. Gunakan cetak browser atau buka aplikasi pada tab baru. |
| Varian/perbandingan tipe berubah | Jalankan pencarian ulang agar tahap tepat; lengkapi konfirmasi pembanding. |
| Draf tidak tersimpan di Google Sites | Unduh JSON atau buka aplikasi langsung di tab baru. |
| Setelah unggah masih versi lama | Muat ulang keras (Ctrl+F5); periksa katalog dan URL hosting yang dipakai. |
| Lokasi/kategori berbeda periode | Periksa sumber DJKN yang berlaku dan dokumentasikan dasar kategori sebelum menerbitkan PDF. |

## 8. Sumber pemasangan

Dokumentasi diperiksa pada 30 September 2026:

- [GitHub Pages: sumber publikasi dan ketersediaan paket](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).
- [GitHub Desktop: clone repositori](https://docs.github.com/en/desktop/adding-and-cloning-repositories/cloning-and-forking-repositories-from-github-desktop).
- [Google Sites: menyematkan URL dan kode](https://support.google.com/sites/answer/90569?hl=en).
- [MDN: pembatasan CORS pada file lokal](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CORS/Errors/CORSRequestNotHttp).
