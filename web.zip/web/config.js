/* Untuk sematan kode Google Sites, isi URL HTTPS manifest.json di bawah. */
globalThis.KMK_CONFIG={manifestUrl:""};