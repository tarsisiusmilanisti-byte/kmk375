(function(root){
 'use strict';
 const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const num=(v,d=2)=>Number.isFinite(v)?new Intl.NumberFormat('id-ID',{minimumFractionDigits:d,maximumFractionDigits:d}).format(v):'—';
 const date=s=>s?new Intl.DateTimeFormat('id-ID',{dateStyle:'long',timeZone:'Asia/Jakarta'}).format(new Date(s+'T05:00:00Z')):'—';
 const damage={low:'Tingkat kerusakan sampai dengan 80%',medium:'Tingkat kerusakan di atas 80% s.d. 90%',high:'Tingkat kerusakan di atas 90%'};
 const classText=c=>({low:'Low end',middle:'Middle',high:'High end'}[c]||'—');
 function sections(d){const {s,form:f,calc:c}=d;
  const docs=s.ownership?[f.bpkb?'BPKB':'',f.stnk?'STNK':'',f.otherDocCheck?f.otherDoc:''].filter(Boolean).join(', '):'Tidak ada';
  const identity=[['Nomor kertas kerja',f.reportNo,'Tanggal',date(s.date)],['1. IDENTIFIKASI OBJEK','','',''],['a. Nama objek',f.objectName||s.brand+' '+s.type,'NUP',f.nup],['b. Lokasi objek',f.objectLocation,'Kategori lokasi',s.cat],['Rencana lokasi lelang',s.loc,'Jenis kendaraan',s.kind==='Motor'?'Roda 2 atau 3':'Roda 4 atau lebih'],['c. Merek kendaraan',s.brand,'Tipe kendaraan',s.type],['d. Nomor polisi',f.plate,'Dokumen kepemilikan',docs],['Pemilik dokumen',s.ownership?f.owner:'Tidak ada','Masa berlaku',s.ownership?f.docValidity:'Tidak ada'],['Penggunaan kendaraan',f.use||'—','Keterangan lain',f.notes||'—'],['2. FISIK KENDARAAN','','',''],['a. Warna',f.color,'Kondisi',damage[s.damage]],['b. Tahun pembuatan',s.year,'Faktor kondisi',num(c.k,1)],['c. Bahan bakar',f.fuel,'Kelas / kapasitas',classText(s.cls)+(s.cc?' / '+s.cc+' cc':' / pilihan panitia')]];
  const auctionHead=['No.','Merek','Kode lelang','Tipe','Harga lelang (Rp)','Tahun lelang','Lokasi lelang','Kat','Tahun buat'];
  const auction=d.comps.map((r,i)=>[i+1,r.brand,r.code,r.type,num(r.price,0),r.auction,r.loc.replace(/^KPKNL /,''),r.cat,r.year]);
  const adjHead=['No.','Merek','Tipe','Merek','Waktu','Lokasi','Tahun buat','Total','Nilai taksiran (Rp)'];
  const adj=c.data.map((r,i)=>[i+1,r.brand,...['adjType','adjBrand','adjTime','adjLoc','adjYear','total'].map(k=>num(r[k],['adjBrand','total'].includes(k)?2:0)+'%'),num(r.adjusted)]);
  const totals=[['Jumlah nilai setelah penyesuaian',num(c.sum)],['Rata-rata nilai taksiran',num(c.avg)],[s.purpose==='lelang'?'Taksiran nilai limit lelang × '+num(c.k,1):'Nilai taksiran penjualan tanpa lelang × '+num(c.k,1),num(c.value)],['Pembulatan ke ribuan terdekat',num(c.rounded)]];
  const selected=d.comps.map(c=>c.id),deviation=d.mode.startsWith('Manual')||selected.length!==d.recommended.length||selected.some(x=>!d.recommended.includes(x));
  const notes=[`Metode: perbandingan data harga penjualan lelang. Acuan: KMK 375 Tahun 2024, Lampiran C, D, dan contoh kertas kerja halaman 27.`,
  `Dataset: ${d.dataset}. Kategori bawaan: ${d.period}. Dasar kategori yang digunakan: ${f.categoryBasis||'belum diisi'}.`,
  `Jumlah pembanding: ${d.comps.length}. Mode: ${d.mode}. ${deviation?'Pilihan pengguna berbeda dari himpunan tahap cukup KMK / menggunakan data manual.':'Seluruh data pada tahap cukup KMK digunakan (maksimal 7).'} Alasan: ${f.selectionReason||'mengikuti himpunan tahap cukup KMK'}.`,
  'Penyesuaian = harga lelang × (1 + jumlah persentase penyesuaian). Waktu 2%/tahun; lokasi 5%/kategori; tahun pembuatan mengikuti kelas objek; tipe 8%/tingkat. Hanya hasil akhir dibulatkan ke ribuan terdekat, mengikuti pola contoh lampiran KMK.',
  ...(d.comps.length<3?['CATATAN JUMLAH: Perhitungan manual menggunakan '+d.comps.length+' pembanding; jumlah ini di bawah minimum 3 pada KMK Lampiran C.3.']:[]),
  ...c.data.filter(x=>x.differentBrand||x.adjBrand!==0).map(x=>'Penyesuaian merek '+x.code+': '+num(x.adjBrand,4)+'%. Rumus: '+(x.brandFormula||'(NJT - NJP) / NJP x 100%')+'. Dasar / sumber: '+(x.brandBasis||'belum diisi')+'.'),
  ...(d.excluded||[]).map(x=>'Data dikeluarkan '+x.code+' (tahap '+x.stage+'): '+x.reason),
  ...d.comps.map(x=>'Pemeriksaan tipe '+x.code+': '+(x.typeBasis||'Tipe baku sama, spesifikasi diperiksa panitia.')+' | Selisih '+x.typeSteps+' tingkat.'),
  'Data transaksi tersedia pada tingkat tahun. Masa berlaku nilai taksiran: 6 bulan sejak tanggal kertas kerja.'];
  return {identity,auctionHead,auction,adjHead,adj,totals,notes};
 }
 function html(d){const b=sections(d),f=d.form;
  const table=(heads,rows,widths)=>`<table class="report-table">${widths?'<colgroup>'+widths.map(w=>`<col style="width:${w}%">`).join('')+'</colgroup>':''}${heads?'<thead><tr>'+heads.map(h=>`<th>${e(h)}</th>`).join('')+'</tr></thead>':''}<tbody>${rows.map(r=>'<tr>'+r.map(v=>`<td>${e(v)}</td>`).join('')+'</tr>').join('')}</tbody></table>`;
  return `<div class="paper">${d.comps.length<3?'<p><strong>PERHITUNGAN MANUAL · JUMLAH PEMBANDING DI BAWAH 3</strong></p>':''}${d.errors.length?'<div class="draft-watermark">DRAF · ISIAN BELUM LENGKAP</div>':''}<div class="report-title"><div class="logo">${d.logo?`<img src="${d.logo}" alt="Logo">`:'LOGO KEMENTERIAN / LEMBAGA'}</div><div><h2>KERTAS KERJA ANALISIS PENENTUAN NILAI TAKSIRAN BMN</h2><p><b>${e(f.institution||'KEMENTERIAN / LEMBAGA')}</b></p><p>${e(f.unit)}</p><p>TUJUAN PEMINDAHTANGANAN DENGAN PENJUALAN</p></div></div>${table(null,b.identity,[21,29,20,30])}<div class="report-band">DATA HASIL LELANG</div>${table(b.auctionHead,b.auction,[4,9,10,20,15,7,19,4,12])}<div class="report-band">PENYESUAIAN</div>${table(b.adjHead,b.adj,[4,12,7,7,7,7,10,8,38])}${table(null,b.totals,[73,27])}<p style="text-align:right">${e(f.city)}, ${e(date(d.s.date))}</p><strong>Panitia Penaksir</strong><div class="signatures">${d.members.map(m=>`<div><div>${e(m.role)}</div><div class="sig-space"></div><div class="sig-name">${e(m.name||'……………………')}</div><div>NIP/NRP ${e(m.nip||'……………………')}</div><div>${e(m.job)}</div></div>`).join('')}</div><div class="report-notes">${b.notes.map(e).join('\n\n')}</div><div class="report-band">CATATAN PENCARIAN DAN PEMBANDING</div>${d.trace.length?table(['Tahap','Kandidat','Rekom.','Status'],d.trace.map(r=>[r.stage,r.found,r.taken,r.status]),[12,18,18,52]):'<p>Pengisian pembanding manual.</p>'}<p class="report-notes">Wilayah pertama: ${e(d.geo.first.join(', ')||'—')}\nWilayah kedua: ${e(d.geo.second.join(', ')||'—')}\nDasar wilayah: ${e(d.geo.basis||'—')}</p>${d.comps.filter(c=>c.source||c.brandBasis).map(c=>`<p class="report-notes">${e(c.code)}: ${e(c.source||'')} ${e(c.brandBasis||'')}${c.compNew?' | NJT Rp '+num(Number(c.subjectNew))+'; NJP Rp '+num(Number(c.compNew)):''}</p>`).join('')}<div class="report-footer">Dokumen dihasilkan dari aplikasi Penaksir KMK 375/2024. Pemeriksaan dan penetapan oleh panitia penaksir.</div></div>`;
 }
 async function pdf(d){
  const lib=root.PDFLib||(typeof require!=='undefined'?require('./vendor/pdf-lib.min.js'):null);if(!lib)throw Error('Mesin PDF tidak tersedia.');
  const {PDFDocument,StandardFonts,rgb}=lib,doc=await PDFDocument.create();
  const kit=root.fontkit||(typeof require!=='undefined'?require('./vendor/fontkit.umd.min.js'):null);
  const fonts=root.KMKFonts||(typeof require!=='undefined'?{regular:require('fs').readFileSync(require('path').join(__dirname,'fonts/DejaVuSans.ttf')),bold:require('fs').readFileSync(require('path').join(__dirname,'fonts/DejaVuSans-Bold.ttf'))}:null);
  if(kit&&fonts)doc.registerFontkit(kit);
  const font=await doc.embedFont(fonts?fonts.regular:StandardFonts.Helvetica,{subset:true}),bold=await doc.embedFont(fonts?fonts.bold:StandardFonts.HelveticaBold,{subset:true});
  doc.setTitle('Kertas Kerja Penentuan Nilai Taksiran BMN - '+d.form.plate);doc.setAuthor(d.form.institution);doc.setSubject('KMK 375 Tahun 2024');doc.setCreator('Penaksir Kendaraan KMK 375/2024');
  const W=595.28,H=841.89,M=30,CW=W-2*M;let page,y,pageNumber=0;
  const safe=v=>String(v??'').replace(/[–—−]/g,'-').replace(/≤/g,'<=').replace(/≥/g,'>=').replace(/→/g,'->').replace(/…/g,'...').replace(/[^\x20-\x7e\xa0-\xff\n]/g,'?');
  function newPage(){page=doc.addPage([W,H]);y=H-M;pageNumber++;if(pageNumber>1){page.drawText(safe('Kertas Kerja '+d.form.reportNo+' - '+d.form.plate),{x:M,y:y-8,size:8,font:bold});y-=22;}}
  function ensure(h){if(y-h<M+22)newPage();}
  function lines(text,size,width,f=font){text=safe(text);let result=[];for(const p of text.split('\n')){let line='';for(const word of p.split(/\s+/)){if(!word)continue;let chunks=[word];if(f.widthOfTextAtSize(word,size)>width){chunks=[];let part='';for(const c of word){if(f.widthOfTextAtSize(part+c,size)>width&&part){chunks.push(part);part='';}part+=c;}if(part)chunks.push(part);}for(const piece of chunks){if(line&&f.widthOfTextAtSize(line+' '+piece,size)>width){result.push(line);line=piece;}else line=line?line+' '+piece:piece;}}result.push(line);}return result.length?result:[''];}
  function text(t,{size=8,b=false,align='left',width=CW,gap=4}={}){const f=b?bold:font,ls=lines(t,size,width,f),h=ls.length*size*1.3+gap;ensure(h);for(const l of ls){let x=M;if(align==='right')x=M+width-f.widthOfTextAtSize(l,size);if(align==='center')x=M+(width-f.widthOfTextAtSize(l,size))/2;page.drawText(l,{x,y:y-size,font:f,size});y-=size*1.3;}y-=gap;}
  function band(title){ensure(20);page.drawRectangle({x:M,y:y-16,width:CW,height:16,color:rgb(.85,.85,.85),borderWidth:.5,borderColor:rgb(.4,.4,.4)});const t=safe(title);page.drawText(t,{x:M+(CW-bold.widthOfTextAtSize(t,8))/2,y:y-11,size:8,font:bold});y-=16;}
  function table(heads,data,widths,options={}){const size=options.size||7,pad=3,ws=widths.map(x=>CW*x/100),headerSize=size;
   function row(r,header=false){const f=header?bold:font,ls=r.map((v,i)=>lines(v,size,ws[i]-pad*2,f)),height=Math.max(...ls.map(l=>l.length))*size*1.2+pad*2;
    if(y-height<M+22){newPage();if(heads&&!header)row(heads,true);}
    let x=M;ls.forEach((l,i)=>{page.drawRectangle({x,y:y-height,width:ws[i],height,borderColor:rgb(.45,.45,.45),borderWidth:.35,...header?{color:rgb(.93,.93,.93)}:{}});l.forEach((t,j)=>{let tx=x+pad;if(options.right?.includes(i)&&!header)tx=x+ws[i]-pad-f.widthOfTextAtSize(t,size);page.drawText(t,{x:tx,y:y-pad-size-j*size*1.2,size,font:f});});x+=ws[i];});y-=height;
   }if(heads)row(heads,true);data.forEach(r=>row(r));y-=5;
  }
  newPage();const b=sections(d),f=d.form;
  // Header box follows the sample: logo left, institution and title on the right.
  const headerText=['KERTAS KERJA ANALISIS PENENTUAN NILAI TAKSIRAN BMN',f.institution||'KEMENTERIAN / LEMBAGA',f.unit,'TUJUAN PEMINDAHTANGANAN DENGAN PENJUALAN'];
  const headerLines=headerText.flatMap(t=>lines(t,8.2,CW-105,bold)),headerHeight=Math.max(62,headerLines.length*10+12);
  page.drawRectangle({x:M,y:y-headerHeight,width:CW,height:headerHeight,borderWidth:.7,borderColor:rgb(0,0,0),color:rgb(1,1,1)});page.drawLine({start:{x:M+92,y},end:{x:M+92,y:y-headerHeight},thickness:.5});
  if(d.logo){try{const img=d.logo.startsWith('data:image/png')?await doc.embedPng(d.logo):await doc.embedJpg(d.logo);const size=img.scale(Math.min(74/img.width,(headerHeight-14)/img.height));page.drawImage(img,{x:M+(92-size.width)/2,y:y-(headerHeight+size.height)/2,width:size.width,height:size.height});}catch{page.drawText('LOGO',{x:M+30,y:y-headerHeight/2,size:8,font});}}
  else{page.drawText('KEMENTERIAN /',{x:M+10,y:y-headerHeight/2+5,size:7,font});page.drawText('LEMBAGA',{x:M+27,y:y-headerHeight/2-5,size:7,font});}
  headerLines.forEach((t,i)=>page.drawText(t,{x:M+98+(CW-105-bold.widthOfTextAtSize(t,8.2))/2,y:y-12-i*10,font:bold,size:8.2}));y-=headerHeight+7;
  if(d.errors.length)text('DRAF - ISIAN BELUM LENGKAP',{b:true,align:'center'});
  if(d.comps.length<3)text('PERHITUNGAN MANUAL - JUMLAH PEMBANDING DI BAWAH 3',{b:true,size:8,align:'center'});
  table(null,b.identity,[21,29,20,30],{size:7.2});band('DATA HASIL LELANG');table(b.auctionHead,b.auction,[4,9,10,20,15,7,19,4,12],{size:6.8,right:[4]});band('PENYESUAIAN');table(b.adjHead,b.adj,[4,12,7,7,7,7,10,8,38],{size:6.8,right:[8]});table(null,b.totals,[74,26],{size:7.8,right:[1]});
  ensure(120);text(f.city+', '+date(d.s.date),{align:'right',size:8});text('Panitia Penaksir',{b:true,size:8});
  for(let start=0;start<d.members.length;start+=3){const chunk=d.members.slice(start,start+3),cw=CW/3;const names=chunk.map(m=>lines(m.name,8,cw-12,bold)),jobs=chunk.map(m=>lines(m.job,7,cw-12));const height=60+Math.max(...names.map(a=>a.length))*10+Math.max(...jobs.map(a=>a.length))*9;ensure(height);
   chunk.forEach((m,i)=>{const x=M+i*cw;const center=(t,dy,sz=8,b=false)=>{const ff=b?bold:font;page.drawText(safe(t),{x:x+(cw-ff.widthOfTextAtSize(safe(t),sz))/2,y:y-dy,size:sz,font:ff});};center(m.role,8,7);names[i].forEach((n,j)=>center(n,49+j*10,8,true));center('NIP/NRP '+m.nip,49+names[i].length*10,7);jobs[i].forEach((n,j)=>center(n,59+names[i].length*10+j*9,7));});y-=height+6;
  }
  newPage();band('CATATAN PERHITUNGAN DAN PEMILIHAN DATA');b.notes.forEach(t=>text(t,{size:8,gap:9}));
  if(d.trace.length){band('JEJAK TAHAP PENCARIAN');table(['Tahap','Kandidat','Rekom.','Status'],d.trace.map(r=>[r.stage,r.found,r.taken,r.status]),[12,18,18,52],{size:8});}
  text('Wilayah urutan pertama: '+(d.geo.first.join(', ')||'-'),{size:8,gap:7});text('Wilayah urutan kedua: '+(d.geo.second.join(', ')||'-'),{size:8,gap:7});text('Dasar wilayah: '+(d.geo.basis||'-'),{size:8,gap:7});
  const detail=d.comps.filter(c=>c.source||c.brandBasis);if(detail.length){band('SUMBER PEMBANDING MANUAL / PENYESUAIAN MEREK');for(const c of detail)text(c.code+': '+(c.source||'')+' '+(c.brandBasis||'')+(c.compNew?' | NJT Rp '+num(Number(c.subjectNew))+'; NJP Rp '+num(Number(c.compNew)):''),{size:8,gap:8});}
  const pages=doc.getPages();pages.forEach((p,i)=>{p.drawLine({start:{x:M,y:29},end:{x:W-M,y:29},thickness:.4,color:rgb(.6,.6,.6)});p.drawText(safe('KMK 375 Tahun 2024 | '+d.form.reportNo),{x:M,y:18,font,size:7});const t=(i+1)+' / '+pages.length;p.drawText(t,{x:W-M-font.widthOfTextAtSize(t,7),y:18,font,size:7});});return doc.save();
 }
 const api={sections,html,pdf};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.KMKReport=api;
})(typeof globalThis!=='undefined'?globalThis:this);
