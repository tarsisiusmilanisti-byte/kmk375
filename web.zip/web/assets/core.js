/* Penaksir KMK 375/2024. Pure functions shared by the offline UI and regression checks. */
(function (root) {
 'use strict';
 const norm = s => String(s ?? '').normalize('NFKC').trim().toUpperCase().replace(/[^A-Z0-9]/g,'');
 const brand = s => ({MERCEDES:'MERCEDESBENZ',VW:'VOLKSWAGEN',VWVOLKSWAGEN:'VOLKSWAGEN'}[norm(s)] || norm(s));
 const location = s => norm(s).replace('PADANGSIDEMPUAN','PADANGSIDIMPUAN');
 const number = s => {let v=String(s??'').trim().replace(/Rp\.?\s*/ig,'').replace(/\s/g,''); if(/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(v))v=v.replace(/\./g,'').replace(',','.');else if(/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(v))v=v.replace(/,/g,'');else v=v.replace(',','.');return Number(v);};
 function parseCSV(text) {
  text=text.replace(/^\uFEFF/,'');const first=text.split(/\r?\n/,1)[0];const delimiter=(first.match(/;/g)||[]).length>(first.match(/,/g)||[]).length?';':',';
  const rows=[]; let row=[],field='',quoted=false;
  for(let i=0;i<text.length;i++){let c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){field+='"';i++;}else quoted=!quoted;}else if(c===delimiter&&!quoted){row.push(field);field='';}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);if(row.some(x=>x.trim()))rows.push(row);row=[];field='';}else field+=c;}
  if(quoted)throw Error('Tanda kutip CSV tidak lengkap.');row.push(field);if(row.some(x=>x.trim()))rows.push(row);return rows;
 }
 function ccFromType(t,kind){
  const found=[...String(t).matchAll(/\b(\d{1,2}[.,]\d{3}|\d{2,5})\s*(?:cc|cm3)\b/ig)].map(m=>Number(m[1].replace(/[.,]/g,'')));
  if(!found.length&&kind==='Mobil')for(const m of String(t).matchAll(/\b(\d[.,]\d)\s*L\b/ig))found.push(Number(m[1].replace(',','.'))*1000);
  const a=[...new Set(found)].filter(v=>v>=30&&v<=20000);return a.length===1?a[0]:null;
 }
 function vehicleClass(kind,cc){if(!(cc>0))return '';let limits=kind==='Motor'?[100,150]:[1200,2500];return cc<=limits[0]?'low':cc<=limits[1]?'middle':'high';}
 const rate = c => ({low:5,middle:7,high:10}[c] || 0);
 const classLabel = c => ({low:'Low end',middle:'Middle',high:'High end'}[c] || 'Belum teridentifikasi');
 function prepareCSV(text){
  const matrix=parseCSV(text),head=matrix.shift()||[];const idx=k=>head.indexOf(k);for(const k of ['Kode','Objek','KPKNL','Tahun Lelang','Merek','Tipe','Tahun Pembuatan','Harga Laku (Rp)'])if(idx(k)<0)throw Error('Kolom CSV tidak ditemukan: '+k);
  const catCols=head.map((h,i)=>{const m=h.match(/Kat\. Lokasi \(Semester (II|I) (\d{4})\)/i);return m?{i,key:m[2]+'-'+(m[1].toUpperCase()==='II'?2:1)}:null;}).filter(Boolean);
  if(!catCols.length)throw Error('Kolom kategori lokasi semester tidak ditemukan.');
  const codes=new Map();matrix.forEach(r=>codes.set(r[idx('Kode')],(codes.get(r[idx('Kode')])||0)+1));
  const rows=matrix.map((r,i)=>{const get=k=>r[idx(k)]||'';let kind=norm(get('Objek'))==='MOTOR'?'Motor':norm(get('Objek')).startsWith('MOBIL')?'Mobil':'';
   const normalized=idx('Model_Baku')>=0;
   if(normalized)kind=get('Jenis_Objek_Baku')||kind;
   const cc=number(get('Kapasitas_CC_Baku'))||ccFromType(get('Tipe'),kind),year=number(get('Tahun Pembuatan')),auction=number(get('Tahun Lelang')),price=number(get('Harga Laku (Rp)')),code=get('Kode').trim(),flags=[];
   if(codes.get(code)>1)flags.push('Kode lelang berulang; periksa objek/lot dan harga per unit');
   if(!code)flags.push('Kode lelang kosong');if(!kind)flags.push('Jenis kendaraan tidak dikenal');
   if(!Number.isInteger(year)||year<1900||year>auction)flags.push('Tahun pembuatan tidak valid');
   if(!Number.isInteger(auction)||auction<1900)flags.push('Tahun lelang tidak valid');if(!Number.isFinite(price)||price<=0)flags.push('Harga tidak valid');
   if(/\b\d+\s*(?:unit|buah)\b|\bdan\b/i.test(get('Tipe')))flags.push('Deskripsi berpotensi memuat beberapa kendaraan');
   if(normalized&&get('Siap_Pencarian_Model')!=='Ya')flags.push(get('Status_Kualitas_Normalisasi')||'Identitas model belum terverifikasi');
   const cats={};catCols.forEach(c=>cats[c.key]=number(r[c.i]));
   const cls=({'low end':'low','low-end':'low',low:'low',middle:'middle','high end':'high','high-end':'high',high:'high'}[get('Kelas_Kapasitas_Baku').toLowerCase()]||vehicleClass(kind,cc));
   return {id:get('ID Baris')||'L'+String(i+1).padStart(5,'0'),code,kind,loc:get('KPKNL'),auction,cats,brand:get('Merek_Baku')||get('Merek'),rawBrand:get('Merek'),type:get('Tipe_Baku')||get('Tipe'),rawType:get('Tipe'),model:get('Model_Baku'),variant:get('Varian_Baku'),generation:get('Generasi_Baku'),transmission:get('Transmisi_Baku'),fuel:get('Bahan_Bakar_Baku'),body:get('Bentuk_Kendaraan_Baku'),tier:number(get('Tier_Urutan'))||null,tierGroup:get('Kelompok_Tier'),tierSource:get('Sumber_Tier'),package:get('Paket_Varian'),ccBasis:get('Dasar_Kapasitas_Baku'),variantStatus:get('Status_Varian'),year,color:get('Warna'),price,cc,cls,flags,sourceLine:i+2};
  });return {rows,periods:catCols.map(c=>c.key).sort(),head,matrix};
 }
 const families=[['corolla',/COROL+LA|COROLA/i],['innova',/INNOVA/i],['avanza',/AVANZA/i],['fortuner',/FORTUNER/i],['kijang',/KIJANG|\bKF\s*[458][02]/i],['camry',/CAMRY/i],['rush',/\bRUSH\b/i],['yaris',/YARIS/i],['vios',/VIOS/i],['hilux',/HILUX/i],['agya',/AGYA/i],['calya',/CALYA/i],['hiace',/HIACE/i],['dyna',/DYNA/i],['panther',/PANTHER/i],['xenia',/XENIA/i],['terios',/TERIOS/i],['ayla',/AYLA/i],['sigra',/SIGRA/i],['granmax',/GRAN[ -]?MAX/i],['luxio',/LUXIO/i],['taft',/TAFT/i],['taruna',/TARUNA/i],['apv',/\bAPV\b|GC415/i],['ertiga',/ERTIGA/i],['carry',/CARRY|FUTURA/i],['katana',/KATANA/i],['jimny',/JIMNY/i],['grandvitara',/VITARA/i],['pajero',/PAJERO/i],['strada',/STRADA|TRITON|L200/i],['kuda',/KUDA/i],['l300',/L\s*300/i],['t120',/T\s*120/i],['livina',/LIVINA/i],['xtrail',/X[ -]?TRAIL/i],['terrano',/TERRANO/i],['ranger',/RANGER/i],['crv',/CR[ -]?V\b/i],['civic',/CIVIC/i],['accord',/ACCORD/i],['jazz',/JAZZ/i],['brio',/BRIO/i],['supra',/SUPRA/i],['revo',/REVO/i],['beat',/BEAT/i],['vario',/VARIO/i],['scoopy',/SCOOPY/i],['karisma',/KARISMA|KHARISMA/i],['megapro',/MEGA\s*PRO/i],['tiger',/TIGER/i],['win',/\bWIN\b/i],['glmax',/GL[ -]?MAX/i],['glpro',/GL[ -]?PRO/i],['cbr',/CBR/i],['vixion',/V[ -]?IXION/i],['jupiter',/JUPITER/i],['vega',/VEGA/i],['mio',/\bMIO\b/i],['scorpio',/SCORPIO/i],['nmax',/N[ -]?MAX/i],['aerox',/AEROX/i],['rxking',/RX[ -]?KING/i],['smash',/SMASH/i],['shogun',/SHOGUN/i],['satria',/SATRIA/i],['klx',/KLX/i],['ninja',/NINJA/i]];
 function family(t){const f=families.find(([,rx])=>rx.test(t));return f?f[0]:'';}
 function comparableType(a,b){if(norm(a)===norm(b))return true;return family(a)!==''&&family(a)===family(b);}
 function special(loc){let s=location(loc);return s.includes('BATAM')?'batam':s.includes('SABANG')?'sabang':'';}
 function allowedSpecial(a,b){return special(a)===special(b);}
 function sameModel(s,r){return s.model&&r.model?norm(s.model)===norm(r.model):norm(s.type)===norm(r.type);}
 function sameType(s,r){return sameModel(s,r)&&norm(s.variant||'')===norm(r.variant||'')&&norm(s.type)===norm(r.type);}
 function recommend(pool){
  const chosen=[],trace=[];let stop=null;
  for(let stage=1;stage<=8;stage++){
   const all=pool.filter(r=>r.stage===stage),eligible=all.filter(r=>!r.excluded);
   let taken=[];
   if(stop===null){
    taken=eligible.slice().sort((a,b)=>a.price-b.price||a.code.localeCompare(b.code)).slice(0,7-chosen.length);
    chosen.push(...taken.map(r=>r.id));if(chosen.length>=3)stop=stage;
   }
   trace.push({stage,found:all.length,eligible:eligible.length,taken:taken.length,status:stop!==null&&stage>stop?'Referensi tambahan':taken.length?'Direkomendasikan':'Tidak ada data layak'});
  }
  trace.push({stage:9,found:0,eligible:0,taken:0,status:'Manual: merek berbeda'},{stage:10,found:0,eligible:0,taken:0,status:'Manual: merek berbeda'});
  return {recommended:stop===null?[]:chosen,trace,stopStage:stop};
 }
 function search(rows,s,geo){
  const recent=rows.filter(r=>!r.flags.length&&r.kind===s.kind&&r.auction>=s.evalYear-3&&r.auction<=s.evalYear&&Math.abs(r.year-s.year)<=5&&allowedSpecial(s.loc,r.loc));
  const sameBrand=recent.filter(r=>brand(r.brand)===brand(s.brand));
  const base=sameBrand.filter(r=>sameModel(s,r));
  const local=r=>location(r.loc)===location(s.loc),in1=r=>geo.first.some(l=>location(l)===location(r.loc)),in2=r=>geo.second.some(l=>location(l)===location(r.loc));
  const exact=r=>sameType(s,r)&&r.year===s.year;
  const filters=[r=>local(r)&&exact(r),r=>in1(r)&&exact(r),local,in1,r=>in2(r)&&exact(r),in2,exact,()=>true];
  const used=new Set(),pool=[];
  // A sufficient local stage can be used immediately. Expansion requires a checked region order.
  const localExact=base.filter(r=>local(r)&&exact(r));
  const needGeo=!geo.confirmed&&!special(s.loc)&&localExact.length<3&&base.length>=3;
  for(let i=0;i<8;i++){
   if(!geo.confirmed&&!special(s.loc)&&i>0)break;
   const eligible=base.filter(r=>!used.has(r.id)&&filters[i](r)).sort((a,b)=>Math.abs(a.year-s.year)-Math.abs(b.year-s.year)||a.price-b.price||a.code.localeCompare(b.code));
   eligible.forEach(r=>{used.add(r.id);pool.push({...r,stage:i+1});});
  }
  return {pool,...recommend(pool),needGeo,expansionPending:!geo.confirmed&&!special(s.loc),sameBrandCount:sameBrand.length,eligibleCount:base.length};
 }
 function selectionErrors(pool,comps){
  const e=[];for(const c of pool)if(c.excluded&&!String(c.excludeReason||'').trim())e.push('Isi alasan ketidaklayakan kandidat '+c.code+'.');
  const rec=recommend(pool).recommended,ids=comps.map(c=>c.id);
  if(ids.length!==rec.length||ids.some(id=>!rec.includes(id)))e.push('Pilihan belum mengikuti tahap cukup KMK C.4. Gunakan rekomendasi KMK; keluarkan data yang tidak layak dengan alasan faktual lalu hitung ulang rekomendasi.');
  return e;
 }
 function suggestType(s,c){
  if(sameType(s,c))return {steps:0,basis:'Nama tipe baku sama; periksa spesifikasi sebelum digunakan.'};
  const g=s.tierGroup&&s.tierGroup===c.tierGroup;
  if(g&&s.tier&&c.tier)return {steps:s.tier-c.tier,basis:'Usulan urutan '+s.tierGroup+' ('+(c.tierSource||'master dataset')+'). Berlaku hanya jika generasi dan spesifikasi selain varian sebanding.'};
  return {steps:'',basis:'Urutan tipe belum dipastikan. Tentukan setelah memeriksa spesifikasi; jangan menyamakan kelas kapasitas dengan kelas varian.'};
 }
 function condition(purpose,damage,doc){if(purpose==='lelang'&&!doc)return .5;return purpose==='lelang'?({low:.7,medium:.6,high:.5}[damage]):({low:1,medium:.9,high:.8}[damage]);}
 function brandAdjustment(s,c){
  if(brand(c.brand)===brand(s.brand))return 0;
  if(Object.prototype.hasOwnProperty.call(c,'brandPercent'))return c.differentBrand?percent(c.brandPercent):0;
  return (Number(c.subjectNew)/Number(c.compNew)-1)*100;
 }
 function percent(v){const t=String(v??'').trim();return /^[+-]?(?:\d+(?:[.,]\d+)?|[.,]\d+)$/.test(t)?Number(t.replace(',','.')):NaN;}
 function calculate(s,comps){
  const data=comps.map(c=>{const adjType=Number(c.typeSteps)*8,adjBrand=brandAdjustment(s,c),adjTime=(s.evalYear-c.auction)*2,adjLoc=(c.cat-s.cat)*5,adjYear=(s.year-c.year)*rate(s.cls);const total=adjType+adjBrand+adjTime+adjLoc+adjYear;return {...c,adjType,adjBrand,adjTime,adjLoc,adjYear,total,adjusted:c.price*(1+total/100)};});
  const sum=data.reduce((a,c)=>a+c.adjusted,0),avg=sum/data.length,k=condition(s.purpose,s.damage,s.ownership),value=avg*k;return {data,sum,avg,k,value,rounded:Math.round(value/1000)*1000};
 }
 function validateComparables(s,comps,{min=3}={}){const errors=[];if(comps.length<min||comps.length>7)errors.push('Pilih '+min+' sampai 7 pembanding.');const keys=new Set();for(const [i,c] of comps.entries()){const p='Pembanding '+(i+1)+': ';if(c.kind&&c.kind!==s.kind)errors.push(p+'jenis kendaraan berbeda dari objek.');if(c.flags?.length)errors.push(p+'data sumber memiliki masalah kualitas: '+c.flags.join('; '));if(!c.brand||!c.type||!c.loc||!c.code)errors.push(p+'identitas belum lengkap.');if(keys.has(norm(c.code)))errors.push(p+'kode lelang duplikat.');keys.add(norm(c.code));if(!Number.isFinite(c.price)||c.price<=0)errors.push(p+'harga harus lebih dari nol.');if(!Number.isInteger(c.year)||c.year>s.evalYear||Math.abs(c.year-s.year)>5)errors.push(p+'tahun pembuatan harus dalam rentang ±5 tahun objek.');if(!Number.isInteger(c.auction)||c.auction<s.evalYear-3||c.auction>s.evalYear||c.year>c.auction)errors.push(p+'tahun lelang tidak memenuhi batas 3 tahun / mendahului tahun pembuatan.');if(![1,2,3,4].includes(Number(c.cat)))errors.push(p+'kategori lokasi harus 1–4.');if(c.typeSteps===''||!Number.isInteger(Number(c.typeSteps)))errors.push(p+'pilih perbedaan kelas tipe.');if(Math.abs(Number(c.typeSteps))>10)errors.push(p+'selisih kelas tipe di luar rentang formulir.');if(!allowedSpecial(s.loc,c.loc))errors.push(p+'data Batam/Sabang tidak dapat dicampur dengan wilayah lain.');if(Object.prototype.hasOwnProperty.call(c,'brandPercent')){
 const different=brand(c.brand)!==brand(s.brand);
 if(different&&!c.differentBrand)errors.push(p+'centang Beda merek dan lengkapi penyesuaian merek.');
 if(!different&&c.differentBrand)errors.push(p+'merek sama; lepaskan centang Beda merek.');
 if(c.differentBrand){if(!Number.isFinite(percent(c.brandPercent))||percent(c.brandPercent)<=-100)errors.push(p+'persentase merek harus angka lebih besar dari -100%.');if(!String(c.brandFormula||'').trim())errors.push(p+'isi keterangan rumus penyesuaian merek.');if(!String(c.brandBasis||'').trim())errors.push(p+'isi dasar dan sumber penyesuaian merek.');}
 }else if(brand(c.brand)!==brand(s.brand)&&(!(Number(c.subjectNew)>0)||!(Number(c.compNew)>0)||!c.brandBasis))errors.push(p+'merek berbeda membutuhkan harga pembanding/objek dan sumber harga.');if(c.excluded)errors.push(p+'data yang dikeluarkan tidak boleh dipilih.');if((!sameType(s,c)||Number(c.typeSteps)!==0)&&!String(c.typeBasis||'').trim())errors.push(p+'isi dasar kesetaraan atau perbedaan tipe.');if(!c.reviewed)errors.push(p+'konfirmasi kesesuaian spesifikasi dan harga per unit.');}
  if(!errors.length&&calculate(s,comps).data.some(c=>!Number.isFinite(c.adjusted)||c.adjusted<=0))errors.push('Penyesuaian menghasilkan nilai tidak positif. Periksa pembanding.');return errors;}
 const api={norm,brand,location,number,parseCSV,prepareCSV,ccFromType,vehicleClass,rate,classLabel,family,comparableType,special,allowedSpecial,sameModel,sameType,recommend,selectionErrors,suggestType,search,condition,percent,brandAdjustment,calculate,validateComparables};
 if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.KMK=api;
})(typeof globalThis!=='undefined'?globalThis:this);
