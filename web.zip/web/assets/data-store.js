/* Static dataset catalogue + model partitions. No API or AI service. */
(function(root){
 'use strict';
 const K=root.KMK||(typeof require==='function'?require('./core.js'):null);
 const key=s=>[s.kind,K.brand(s.brand),K.norm(s.model)].join('|');
 function catalogue(rows,meta={}){
  const models=new Map(),locations=new Map();
  for(const r of rows){
   const k=key(r);if(!models.has(k))models.set(k,{key:k,kind:r.kind,brand:r.brand,model:r.model,variants:new Set(),count:0,ready:0});
   const m=models.get(k);m.count++;if(!r.flags.length)m.ready++;if(r.variant)m.variants.add(r.variant);
   if(!locations.has(r.loc))locations.set(r.loc,{});const cats=locations.get(r.loc);
   for(const [p,c] of Object.entries(r.cats)){if(!cats[p])cats[p]=new Set();if([1,2,3,4].includes(c))cats[p].add(c);}
  }
  return {...meta,format:'kmk-catalogue-v1',count:rows.length,classified:rows.filter(r=>r.cls).length,ready:rows.filter(r=>!r.flags.length).length,
   auctionMin:Math.min(...rows.map(r=>r.auction)),auctionMax:Math.max(...rows.map(r=>r.auction)),
   models:[...models.values()].map(m=>({...m,variants:[...m.variants].sort()})),
   locations:[...locations].sort(([a],[b])=>a.localeCompare(b)).map(([name,cats])=>({name,cats:Object.fromEntries(Object.entries(cats).map(([p,v])=>[p,v.size===1?[...v][0]:null]))}))};
 }
 function pack(rows,version,modelKey){
  const keys=Object.keys(rows[0]||{}),strKeys=keys.filter(k=>typeof rows[0][k]==='string'),strings=[],lookup=new Map();
  const intern=s=>{if(!lookup.has(s)){lookup.set(s,strings.length);strings.push(s);}return lookup.get(s);};
  const values=rows.map(r=>keys.map(k=>strKeys.includes(k)?intern(r[k]||''):k==='flags'?r.flags.map(intern):r[k]));
  return {format:'kmk-model-v1',version,modelKey,keys,strKeys,strings,values};
 }
 function unpack(p){
  if(p?.format!=='kmk-model-v1'||!Array.isArray(p.values)||!Array.isArray(p.keys)||!Array.isArray(p.strings))throw Error('Format data model tidak dikenali.');
  const strings=new Set(p.strKeys);
  return p.values.map(v=>Object.fromEntries(p.keys.map((k,i)=>[k,strings.has(k)?p.strings[v[i]]:k==='flags'?v[i].map(n=>p.strings[n]):v[i]])));
 }
 function httpURL(url,base){
  const u=new URL(url,base);
  if(!['https:','http:'].includes(u.protocol))throw Error('Dataset terpisah harus dibuka melalui alamat HTTPS atau server lokal. Gunakan URL manifest.json atau impor CSV.');
  if(u.username||u.password)throw Error('URL dataset tidak boleh mengandung kredensial.');return u.href;
 }
 async function readJSON(url){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),25000);
  try{const r=await fetch(url,{signal:controller.signal,credentials:'omit',cache:'no-cache'});if(!r.ok)throw Error('HTTP '+r.status);return await r.json();}
  catch(e){throw Error('Data belum berhasil dimuat. Periksa URL, koneksi, dan izin CORS. '+(e.name==='AbortError'?'Batas waktu 25 detik.':e.message));}
  finally{clearTimeout(timer);}
 }
 class Store{
  constructor(){this.catalog=null;this.manifestURL='';this.cache=new Map();this.pending=new Map();this.localGroups=null;this.localCSV=null;this.generation=0;}
  async connect(url){
   const u=httpURL(url,root.document?.baseURI),generation=++this.generation;
   const c=await readJSON(u);
   if(c?.format!=='kmk-catalogue-v1'||!c.version||!Array.isArray(c.models)||!Array.isArray(c.locations)||!Array.isArray(c.periods)||!c.periods.length)throw Error('URL harus mengarah ke manifest.json dari paket aplikasi, bukan halaman pratinjau Drive/CSV.');
   if(generation!==this.generation)return false;
   this.catalog=c;this.manifestURL=u;this.localGroups=null;this.localCSV=null;this.cache.clear();this.pending.clear();return true;
  }
  useLocal(parsed,name,csv){
   this.generation++;this.catalog=catalogue(parsed.rows,{name,version:'impor-'+Date.now(),periods:parsed.periods});this.localGroups=new Map();
   for(const r of parsed.rows){const k=key(r);if(!this.localGroups.has(k))this.localGroups.set(k,[]);this.localGroups.get(k).push(r);}
   this.localCSV=csv;this.cache.clear();this.pending.clear();
  }
  entry(s){return this.catalog?.models.find(m=>m.key===key(s));}
  async getRows(s){
   if(!this.catalog)throw Error('Hubungkan dataset terlebih dahulu.');const k=key(s),m=this.entry(s);if(!m)return [];
   if(this.localGroups)return this.localGroups.get(k)||[];
   if(this.cache.has(k)){const value=this.cache.get(k);this.cache.delete(k);this.cache.set(k,value);return value;}
   if(this.pending.has(k))return this.pending.get(k);
   const generation=this.generation,version=this.catalog.version;
   const p=(async()=>{const raw=await readJSON(httpURL(m.file,this.manifestURL));if(raw.version!==version||raw.modelKey!==k)throw Error('Versi data model berbeda. Unggah seluruh folder data dan muat ulang katalog.');const rows=unpack(raw);
    if(rows.length!==m.count||rows.some(r=>key(r)!==k))throw Error('Isi data model tidak cocok dengan katalog.');
    if(generation===this.generation){this.cache.set(k,rows);while(this.cache.size>5)this.cache.delete(this.cache.keys().next().value);}return rows;
   })();this.pending.set(k,p);try{return await p;}finally{if(this.pending.get(k)===p)this.pending.delete(k);}
  }
  async originalCSV(){if(this.localCSV!==null)return new Blob([this.localCSV],{type:'text/csv;charset=utf-8'});if(!this.catalog?.sourceCSV)throw Error('CSV sumber belum tersedia.');const response=await fetch(httpURL(this.catalog.sourceCSV,this.manifestURL),{credentials:'omit'});if(!response.ok)throw Error('CSV gagal diunduh: HTTP '+response.status);return response.blob();}
 }
 const api={key,catalogue,pack,unpack,Store,httpURL};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.KMKDataStore=api;
})(typeof globalThis!=='undefined'?globalThis:this);
